<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
 * Configuration file for Email library
 */
$config['protocol'] = 'smtp';
$config['charset'] = 'utf-8';
$config['mailtype'] = 'html';
$config['smtp_timeout'] = 5;
$config['smtp_host'] = 'smtp.mandrillapp.com';
$config['smtp_port'] = 587;
$config['smtp_user'] = 'adyadairy';
$config['smtp_pass'] = 'cb985c4699aabaa1b30bebb0e4cf76e2-us13';
